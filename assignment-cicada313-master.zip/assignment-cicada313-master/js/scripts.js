const form = document.getElementById('visaForm');

form.addEventListener('submit', function(event) {
  event.preventDefault();
  
  // Validation for all required fields
  const requiredFields = form.querySelectorAll('[required]');
  let isValid = true;

  requiredFields.forEach(field => {
    if (!field.value.trim()) {
      isValid = false;
      showError(field, `${field.name} is required`);
    } else {
      hideError(field);
    }
  });

  // Validation for email format
  const emailField = form.querySelector('#email');
  const emailValue = emailField.value.trim();
  if (!isValidEmail(emailValue)) {
    isValid = false;
    showError(emailField, 'Please enter a valid email address');
  } else {
    hideError(emailField);
  }

  if (isValid) {
    // Form is valid, submit it
    // Reset the form
    form.reset();
    // Show success message
    showSuccessMessage();
  }
});

// Function to show success message
function showSuccessMessage() {
  const successMessage = document.getElementById('successMessage');
  successMessage.style.display = 'block';
  setTimeout(function() {
    successMessage.style.display = 'none';
  }, 3000); // Hide success message after 3 seconds
}

// Function to show error message for a field
function showError(field, errorMessage) {
  const errorElement = document.createElement('div');
  errorElement.classList.add('error-message');
  errorElement.innerText = errorMessage;
  field.parentNode.appendChild(errorElement);
}

// Function to hide error message for a field
function hideError(field) {
  const errorElement = field.parentNode.querySelector('.error-message');
  if (errorElement) {
    errorElement.remove();
  }
}

// Function to validate email format
function isValidEmail(email) {
  // email format validation using regular expression
  const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailPattern.test(email);
}