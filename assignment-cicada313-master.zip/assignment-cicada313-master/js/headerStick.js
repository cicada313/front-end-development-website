// stick header to the top ===========

window.addEventListener("scroll", function () {
    var header = document.getElementById("headerNav");
    if (window.scrollY > 0) {
      header.classList.add("sticky");
    } else {
      header.classList.remove("sticky");
    }
  });

  // open Menu =======
function openMenu() {
  const mobileMenu = document.getElementById("mobileMenu");
  const menuIcon = document.getElementById("menuIcon");
  const cross = document.getElementById("cross");
  cross.style.display = "block";
  menuIcon.style.display = "none";
  mobileMenu.style.display = "block";
}


// close Menu =======
function closeMenu() {
  const mobileMenu = document.getElementById("mobileMenu");
  const menuIcon = document.getElementById("menuIcon");
  const cross = document.getElementById("cross");
  cross.style.display = "none";
  menuIcon.style.display = "block";
  mobileMenu.style.display = "none";
}