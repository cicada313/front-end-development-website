const validateForm = () => {
    let isValid = true;

    const name = document.getElementById('name').value.trim();
    const mobile = document.getElementById('mobile').value.trim();
    const phone = document.getElementById('phone').value.trim();
    const email = document.getElementById('email').value.trim();
    const subject = document.getElementById('subject').value.trim();
    const message = document.getElementById('message').value.trim();

    const nameError = document.getElementById('nameError');
    const mobileError = document.getElementById('mobileError');
    const phoneError = document.getElementById('phoneError');
    const emailError = document.getElementById('emailError');
    const subjectError = document.getElementById('subjectError');
    const messageError = document.getElementById('messageError');

    // Name validation
    if (name === '') {
        nameError.textContent = 'Name is required';
        isValid = false;
    } else {
        nameError.textContent = '';
    }

    // Mobile phone validation
    if (mobile === '') {
        mobileError.textContent = 'Mobile phone is required';
        isValid = false;
    } else {
        mobileError.textContent = '';
    }

    // Email validation
    if (email === '') {
        emailError.textContent = 'Email is required';
        isValid = false;
    } else if (!isValidEmail(email)) {
        emailError.textContent = 'Invalid email format';
        isValid = false;
    } else {
        emailError.textContent = '';
    }

    // Subject validation
    if (subject === '') {
        subjectError.textContent = 'Subject is required';
        isValid = false;
    } else {
        subjectError.textContent = '';
    }

    // Message validation
    if (message === '') {
        messageError.textContent = 'Message is required';
        isValid = false;
    } else {
        messageError.textContent = '';
    }

  // Display success message if everything is valid
  if (isValid) {
    document.getElementById('successMessage').style.display = 'block';

    // Log form data to console
    console.log("Submitted data:");
    console.log("Name:", name);
    console.log("Mobile Phone:", mobile);
    console.log("Landline Phone:", phone);
    console.log("Email:", email);
    console.log("Subject:", subject);
    console.log("Message:", message);
 
    // Reset form fields
     document.getElementById('contactForm').reset();
}

    return false; // Prevent form submission
};

const isValidEmail = (email) => {
    // email validation
    const re = /\S+@\S+\.\S+/;
    return re.test(email);
};